#include <string> // Added this line to include the string header file
#ifndef CARD_OPERATIONS_H
#define CARD_OPERATIONS_H
void recharge(std::string username); // Changed string to std::string

#endif