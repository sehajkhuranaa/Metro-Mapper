
#ifndef GRAPH_OPERATIONS_H
#define GRAPH_OPERATIONS_H

void loadGraph1();
void loadGraph2();

#endif