!#/bin/bash

git add .
git commit -m "a default commit message"
git push origin
